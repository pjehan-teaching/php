<?php
// Déclaration des variables

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Forum</title>
        <link rel="stylesheet" href="font-awesome/css/font-awesome.css"/>
    </head>
    <body>

        <h1>Mon forum</h1>
        <!-- Code temporaire à supprimer avant la mise en ligne -->
        <fieldset>
            <legend>Badges disponibles</legend>
            <i class="fa fa-2x fa-border fa-user-secret" title="Administrateur"></i>
            <i class="fa fa-2x fa-border fa-birthday-cake" title="Anniversaire"></i>
            <i class="fa fa-2x fa-border fa-bug" title="Flood"></i>
            <i class="fa fa-2x fa-border fa-male" title="Homme"></i>
            <i class="fa fa-2x fa-border fa-female" title="Femme"></i>
            <i class="fa fa-2x fa-border fa-star-o" title="Moins de 50 messages"></i>
            <i class="fa fa-2x fa-border fa-star-half-o" title="Entre 50 et 100 messages"></i>
            <i class="fa fa-2x fa-border fa-star" title="Plus de 100 messages"></i>
            <i class="fa fa-2x fa-border fa-user-plus" title="VIP"></i>
        </fieldset>
        
        <?php
        // Affichage des badges de l'utilisateur
        
        ?>

    </body>
</html>

